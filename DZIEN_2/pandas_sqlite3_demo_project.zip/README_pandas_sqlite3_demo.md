# Pandas + SQLite3 demo project

Pliki:
- `pandas_sqlite3_demo_project.ipynb` - główny notebook Jupyter.

Notebook tworzy lokalną bazę `sklep_demo.sqlite`, zasila ją danymi, pobiera dane do pandas,
wykonuje agregacje, zapisuje raporty do SQLite i eksportuje wynik do CSV.

Wymagane biblioteki:
- pandas
- matplotlib

`sqlite3` jest częścią standardowej biblioteki Pythona.
